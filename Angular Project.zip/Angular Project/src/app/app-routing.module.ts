import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListemployeesComponent } from './employees/listEmployees/listemployees.component';
import { CreateemployeeComponent } from './employees/createEmployee/createemployee.component';
import { EmployeedetailsComponent } from './employees/EmployeeDetails/employeedetails.component';

const routes: Routes = [
 
  { path: 'list', component: ListemployeesComponent },
  { path: 'edit/:id', component: CreateemployeeComponent },
  { path: 'employees/:id', component: EmployeedetailsComponent },
  { path: 'employees/:id/:name', component: EmployeedetailsComponent } 
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
