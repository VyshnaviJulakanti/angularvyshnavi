import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {Employee} from './Models/employee.model';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';


import {HttpClientModule} from '@angular/common/http';

import {ConfirmEqualValidatorDirective} from './confirm-equal-validator.directive';

import { ListemployeesComponent } from './employees/listEmployees/listemployees.component';
import { CreateemployeeComponent } from './employees/createEmployee/createemployee.component';

import { EmployeeFilterPipe } from './employees/employee-filter.pipe';
import { EmployeedetailsComponent } from './employees/EmployeeDetails/employeedetails.component'

@NgModule({
  declarations: [
    AppComponent,
    
    ConfirmEqualValidatorDirective,
   
    ListemployeesComponent,
    CreateemployeeComponent,



    
    EmployeeFilterPipe,
    EmployeedetailsComponent
  ],
  imports: [
    BrowserModule,
    BsDatepickerModule.forRoot(),
    AppRoutingModule,
    FormsModule,
   HttpClientModule

  ],
  providers: [
    Employee],
  bootstrap: [AppComponent]
})
export class AppModule { }
