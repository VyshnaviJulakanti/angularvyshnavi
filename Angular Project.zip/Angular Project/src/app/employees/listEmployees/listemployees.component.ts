import { Component, OnInit } from '@angular/core';
import { Employee } from '../../Models/employee.model';
import { EmployeeserviceService } from '../employeeservice.service';
import { ActivatedRoute, Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-listemployees',
  templateUrl: './listemployees.component.html',
  styleUrls: ['./listemployees.component.css']
})
export class ListemployeesComponent implements OnInit {
  employees: Employee[];

  private selectedEmployeeId: number;
  private employeeToDisplay: Employee;
  filteredEmployees: Employee[];
  private _searchTerm: string;
  private arrayIndex = 1;

  constructor(private _employeeService: EmployeeserviceService,
    private _router: Router,
    private _route: ActivatedRoute) { }

    ngOnInit() {
      this.employees = this._employeeService.getEmployees();
      this.filteredEmployees = this.employees;
      this.selectedEmployeeId = +this._route.snapshot.paramMap.get('id');
    }
    
viewEmployee(employeeId:Number) {
  this._router.navigate(['/employees', employeeId], {
    queryParams: { 'searchTerm': this.searchTerm }
  });
}
editEmployee(employeeId:Number) {
  this._router.navigate(['/edit', employeeId]);
}
deleteEmployee(employeeId){
  this._employeeService.deleteEmployee(employeeId)
  
} 
 
  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(value: string) {
    this._searchTerm = value;
    this.filteredEmployees = this.filterEmployees(value);
  }
  filterEmployees(searchString: string) {
    return this.employees.filter(employee =>
      employee.name.toLowerCase().indexOf(searchString.toLowerCase()) !== -1);
  }
  
}