import { Component, OnInit } from '@angular/core';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Department } from '../../Models/department.model';
import { Employee } from '../../Models/employee.model';
import { EmployeeserviceService } from '../employeeservice.service';
import { Router, ActivatedRouteSnapshot, ActivatedRoute } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-createemployee',
  templateUrl: './createemployee.component.html',
  styleUrls: ['./createemployee.component.css']
})
export class CreateemployeeComponent implements OnInit {
  
panelTitle: string;
datePickerConfig: Partial<BsDatepickerConfig>;
  departments: Department[] = [
    { id: 1, name: 'Help Desk' },
    { id: 2, name: 'HR' },
    { id: 3, name: 'IT' },
    { id: 4, name: 'Payroll' }
  ];
  employee: Employee = {
    id: null,
    name: null,
    gender: null,
    contactPreference: null,
    phoneNumber: null,
    email: null,
    dateOfBirth: null,
    department: null
  }; 

  constructor(private _employeeService: EmployeeserviceService,
    private _router: Router,private _route:ActivatedRoute){
      this.datePickerConfig = Object.assign({},
        {
          containerClass: 'theme-dark-blue',
          dateInputFormat: 'DD/MM/YYYY'
        });
    }

    ngOnInit() {
      this._route.paramMap.subscribe(parameterMap => {
        const id = +parameterMap.get('id');
        this.getEmployee(id);
      });
    }
    private getEmployee(id: number) {
     
      if (id === 0) {
        this.employee = {
          id: null,
          name: null,
          gender: null,
          contactPreference: null,
          phoneNumber: null,
          email: '',
          dateOfBirth: null,
          department: null
        };
       
        
        this.panelTitle = 'Create Employee';
      } else {
       
        this.employee = Object.assign({}, this._employeeService.getEmployee(id));
        this.panelTitle = 'Edit Employee';
      }
    }
    
  saveEmployee(): void {
    this._employeeService.save(this.employee);
    this._router.navigate(['list']);
  }

}
